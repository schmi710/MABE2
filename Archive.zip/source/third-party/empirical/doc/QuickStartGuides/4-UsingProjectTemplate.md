# Using the Project Template

Goals of the project template - Simple web interface - Easy toggle -
Easy debug

Organizing core code files

Debugging

Setting up your interface - Using the Animation object as a base for web
interface?
