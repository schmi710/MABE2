#define CATCH_CONFIG_MAIN
#include "third-party/Catch/single_include/catch2/catch.hpp"

#include "emp/games/Othello8.hpp"

TEST_CASE("Test Othello8", "[games]")
{

}
