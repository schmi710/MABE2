#define CATCH_CONFIG_MAIN

#include "third-party/Catch/single_include/catch2/catch.hpp"

#include "emp/tools/attrs.hpp"

TEST_CASE("Test attrs", "[tools]")
{
}