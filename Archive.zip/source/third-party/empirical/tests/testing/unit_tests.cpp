#define CATCH_CONFIG_MAIN
#include "third-party/Catch/single_include/catch2/catch.hpp"

#include "emp/testing/unit_tests.hpp"

TEST_CASE("Test unit_tests", "[testing]")
{

}
