#define CATCH_CONFIG_MAIN

#include "third-party/Catch/single_include/catch2/catch.hpp"

#include "emp/math/spatial_stats.hpp"

TEST_CASE("Test spatial_stats", "[math]")
{
}