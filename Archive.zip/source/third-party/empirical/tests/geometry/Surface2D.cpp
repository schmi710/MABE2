#define CATCH_CONFIG_MAIN

#include "third-party/Catch/single_include/catch2/catch.hpp"

#include "emp/geometry/Surface2D.hpp"

TEST_CASE("Test Surface2D", "[geometry]")
{
}