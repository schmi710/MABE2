#define CATCH_CONFIG_MAIN

#include "third-party/Catch/single_include/catch2/catch.hpp"

#include "emp/datastructs/reference_vector.hpp"

TEST_CASE("Test reference_vector", "[datastructs]")
{
}