#define CATCH_CONFIG_MAIN

#include "third-party/Catch/single_include/catch2/catch.hpp"

#include "emp/datastructs/ra_set.hpp"

TEST_CASE("Test ra_set", "[datastructs]")
{
}