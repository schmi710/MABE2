#define CATCH_CONFIG_MAIN
#include "third-party/Catch/single_include/catch2/catch.hpp"

#include "emp/config/config_utils.hpp"

TEST_CASE("Test config_utils", "[config]")
{

}
