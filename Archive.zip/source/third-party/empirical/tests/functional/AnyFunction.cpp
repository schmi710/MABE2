#define CATCH_CONFIG_MAIN

#include "third-party/Catch/single_include/catch2/catch.hpp"

#include "emp/functional/AnyFunction.hpp"

TEST_CASE("Test AnyFunction", "[functional]")
{
}