# How to build your own MABE executable

## Overview

## Including MABE Modules

### What modules are available?
* Which types of modules are requires?
* What order should the modules go in?
* How does a custom main function relate to the standard MABE config?

## Launching a mabe object.

## Dealing with extra configuration files